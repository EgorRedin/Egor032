
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _INIT ProgramInit(void)
{
	led_1 = 0;
	led_2 = 0;
}

void _CYCLIC ProgramCyclic(void)
{
	led_1 != led_1;
	int i = 0;
	if (i == 2)
	{
		led_2 != led_2;
		i = 0;
	}
}

void _EXIT ProgramExit(void)
{

}

